/**
 * Vercel Serverless Function  –  POST /api/refine
 *
 * Expects JSON body:  { resume: string, jobDescription: string }
 * Returns JSON:        { result: string }  |  { error: string }
 *
 * The ANTHROPIC_API_KEY env var is set inside the Vercel dashboard
 * (Settings → Environment Variables).  It is NEVER exposed to the browser.
 */

export default async function handler(req, res) {
  /* ── method guard ── */
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  /* ── parse body ── */
  const { resume, jobDescription } = req.body || {};

  if (!resume?.trim() || !jobDescription?.trim()) {
    return res.status(400).json({ error: 'Both resume and jobDescription are required.' });
  }

  /* ── API key check ── */
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'Server misconfiguration: missing API key.' });
  }

  /* ── call Anthropic ── */
  try {
    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 2048,
        messages: [
          {
            role: 'user',
            content: `You are a professional resume and cover letter writer. Given the resume and job description below, do two things:

1. REFINED RESUME – Rewrite the resume so it is well-formatted, uses strong action verbs, and naturally incorporates keywords from the job description to improve ATS compatibility. Keep all factual details accurate; do not invent experience or skills the applicant does not have.

2. COVER LETTER – Write a concise, professional cover letter (≤ 250 words) addressed to "Hiring Manager" that connects the applicant's background to the specific role.

Return ONLY the text below with the exact headers shown – no extra commentary.

REFINED RESUME:
[refined resume here]

---

COVER LETTER:
[cover letter here]

---
RESUME:
${resume.trim()}

JOB DESCRIPTION:
${jobDescription.trim()}`,
          },
        ],
      }),
    });

    if (!upstream.ok) {
      const errBody = await upstream.json().catch(() => ({}));
      throw new Error(errBody.error?.message || `Anthropic API error ${upstream.status}`);
    }

    const data = await upstream.json();
    const result = data.content
      .filter((block) => block.type === 'text')
      .map((block) => block.text)
      .join('\n');

    return res.status(200).json({ result });
  } catch (err) {
    return res.status(500).json({ error: err.message || 'AI processing failed.' });
  }
}
